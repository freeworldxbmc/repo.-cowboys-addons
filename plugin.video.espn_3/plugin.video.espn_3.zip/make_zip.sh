#!/bin/bash
zip -r plugin.video.espn_3.zip * -x .git/\* -x bugs/\* -x \*.pyo -x \*.pyc

